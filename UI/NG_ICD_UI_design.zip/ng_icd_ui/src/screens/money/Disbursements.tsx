import { useState } from 'react';
import { Link } from 'react-router-dom';
import { CheckCircle2, Paperclip, Plus, Search } from 'lucide-react';
import {
  Banner, Button, Chips, DataTable, Drawer, Empty, Field, Input, Kpi, Money, Page, PageHeader, Panel, Pill, SearchInput, Segmented, Select,
  Textarea, fmtD, useToast,
} from '@/ds/components';
import { useQ, delay } from '@/api/query';
import { consignment, consignments, partyName } from '@/mock/core';
import { APPROVERS, CHARGE_NAMES, TODAY, disbursements, fx, invoice, m2, num, type Disb } from '@/mock/money';
import { fmtAmt, whole } from './shared';

/* POST /disbursements. Money the depot paid on the customer's behalf (port
   charges, shipping line charges, customs duty), recovered on an invoice at
   cost or with a handling fee. Writing one off needs approval. */
type Recovery = 'NOT_BILLED' | 'ON_INVOICE' | 'RECOVERED' | 'WRITTEN_OFF' | 'WRITEOFF_PENDING';
type Row = Disb & { pending?: boolean };
const recovery = (d: Row): Recovery => {
  if (d.pending) return 'WRITEOFF_PENDING';
  if (d.status === 'WRITTEN_OFF') return 'WRITTEN_OFF';
  if (d.status === 'RECORDED') return 'NOT_BILLED';
  const inv = d.invoiceId ? invoice(d.invoiceId) : undefined;
  return inv && num(inv.balance) <= 0.005 ? 'RECOVERED' : 'ON_INVOICE';
};
const REC: Record<Recovery, [string, 'wait' | 'go' | 'idle' | 'stop' | 'info']> = {
  NOT_BILLED: ['Not billed yet', 'wait'], ON_INVOICE: ['On invoice, unpaid', 'info'], RECOVERED: ['Recovered', 'go'], WRITTEN_OFF: ['Written off', 'idle'], WRITEOFF_PENDING: ['Write-off awaiting approval', 'wait'],
};
const usd = (d: Disb) => (d.currency === 'USD' ? num(d.amountPaid) : num(d.amountPaid) / fx(TODAY));

export function Disbursements() {
  const toast = useToast();
  const { data } = useQ(['disbursements'], () => delay(disbursements));
  const [local, setLocal] = useState<Row[] | null>(null);
  const rows: Row[] = local ?? data ?? [];
  const [q, setQ] = useState('');
  const [f, setF] = useState<'all' | Recovery>('all');
  const [rec, setRec] = useState(false);
  const [wo, setWo] = useState<Row | null>(null);
  const shown = rows.filter((d) => (f === 'all' || recovery(d) === f) && (!q || [d.disbNo, consignment(d.consignmentId)?.refNo, partyName(d.billToPartyId), d.payeeName].join(' ').toUpperCase().includes(q.toUpperCase())));
  const sum = (r: Recovery) => rows.filter((d) => recovery(d) === r).reduce((a, d) => a + usd(d), 0);

  return (
    <Page>
      <PageHeader title="Disbursements" ms="M3" sub="Paid on the customer's behalf and recovered on their invoice"
        actions={<Button variant="primary" icon={<Plus />} perm="finance.disbursement.record" onClick={() => setRec(true)}>Record disbursement</Button>} />
      <div className="stack-lg">
        <div className="kpi-strip">
          <Kpi label="Not billed yet" value={whole(sum('NOT_BILLED'))} unit="USD" delta="Add to the next invoice" />
          <Kpi label="On invoice, unpaid" value={whole(sum('ON_INVOICE'))} unit="USD" />
          <Kpi label="Recovered" value={whole(sum('RECOVERED'))} unit="USD" />
          <Kpi label="Written off" value={whole(sum('WRITTEN_OFF'))} unit="USD" />
        </div>
        <Panel flush>
          <div className="toolbar">
            <div style={{ width: 260, maxWidth: '100%' }}><SearchInput icon={<Search />} value={q} onChange={(e) => setQ(e.target.value)} placeholder="Number, B/L, customer or payee" aria-label="Filter disbursements" /></div>
            <Chips value={f} onChange={setF} options={[{ id: 'all', label: 'All' }, ...(['NOT_BILLED', 'ON_INVOICE', 'RECOVERED', 'WRITTEN_OFF'] as Recovery[]).map((r) => ({ id: r, label: REC[r][0], count: rows.filter((d) => recovery(d) === r).length }))]} />
          </div>
          <DataTable rows={shown} rowKey={(d) => d.disbursementId} empty={<Empty title="No disbursements match">Clear the search or the filter.</Empty>} cols={[
            { key: 'no', header: 'Disbursement', render: (d) => <span className="strong small nowrap">{d.disbNo}<div className="xs faint">{fmtD(d.paidAt)} · {d.recordedBy}</div></span> },
            { key: 'what', header: 'Paid for', render: (d) => <span className="small">{d.description}<div className="xs faint">{CHARGE_NAMES[d.chargeCode]}</div></span> },
            { key: 'payee', header: 'Paid to', render: (d) => <span className="small">{d.payeeName}<div className="xs faint">Receipt {d.payeeReceiptNo}</div></span> },
            { key: 'cons', header: 'Consignment / bill to', render: (d) => <span className="small">{consignment(d.consignmentId)?.refNo}<div className="xs faint">{partyName(d.billToPartyId)}</div></span> },
            { key: 'amt', header: 'Paid', num: true, render: (d) => <Money amount={d.amountPaid} currency={d.currency} /> },
            { key: 'fee', header: 'Handling fee', num: true, render: (d) => num(d.handlingFee) > 0 ? <Money amount={d.handlingFee} currency={d.currency} /> : <span className="xs faint">At cost</span> },
            { key: 'rec', header: 'Recovery', render: (d) => { const r = recovery(d); const inv = d.invoiceId ? invoice(d.invoiceId) : undefined; return <span><Pill tone={REC[r][1]}>{REC[r][0]}</Pill>{inv && <div className="xs"><Link to={`/invoices/${inv.invoiceId}`}>{inv.invoiceNo}</Link></div>}</span>; } },
            { key: 'act', header: '', render: (d) => d.status === 'RECORDED' && !d.pending ? <Button size="sm" perm="finance.disbursement.record" level="REQ" onClick={() => setWo(d)}>Write off</Button> : null },
          ]} />
        </Panel>
        <p className="xs faint">Re-billed disbursements are outside the VAT scope; the handling fee carries VAT 18%. Verify both with tax adviser before go-live.</p>
      </div>

      <RecordDrawer open={rec} onClose={() => setRec(false)} onDone={(d) => { setLocal([d, ...rows]); toast('Disbursement recorded'); }} />
      <Drawer open={!!wo} onClose={() => setWo(null)} title={`Write off ${wo?.disbNo ?? ''}`}
        footer={<><Button variant="ghost" onClick={() => setWo(null)}>Cancel</Button><Button variant="danger" perm="finance.disbursement.record" level="REQ" onClick={() => { setLocal(rows.map((x) => x === wo ? { ...x, pending: true } : x)); setWo(null); toast('Write-off requested for approval'); }}>Request write-off</Button></>}>
        {wo && <div className="stack">
          <p className="small">{fmtAmt(num(wo.amountPaid), wo.currency)} paid to {wo.payeeName} for {partyName(wo.billToPartyId)} will not be re-billed. It posts to disbursement write-off expense.</p>
          <Banner tone="wait">A write-off always needs approval by {APPROVERS.l1.split(' · ')[0]} (finance manager).</Banner>
          <Field label="Reason" required><Textarea placeholder="e.g. Customer disputes; port charge was caused by depot delay" /></Field>
        </div>}
      </Drawer>
    </Page>
  );
}

function RecordDrawer({ open, onClose, onDone }: { open: boolean; onClose: () => void; onDone: (d: Row) => void }) {
  const [cons, setCons] = useState('101');
  const [code, setCode] = useState('DISB_PORT');
  const [payee, setPayee] = useState('Port authority, Dar es Salaam port');
  const [cur, setCur] = useState<'USD' | 'TZS'>('USD');
  const [amt, setAmt] = useState('');
  const [rct, setRct] = useState('');
  const [mode, setMode] = useState<'AT_COST' | 'COST_PLUS_FEE'>('COST_PLUS_FEE');
  const [fee, setFee] = useState('15');
  const [file, setFile] = useState(false);
  const c = consignment(Number(cons));
  const ok = Number(amt) > 0 && rct.trim() && file;
  return (
    <Drawer open={open} onClose={onClose} title="Record a disbursement"
      footer={<><Button variant="ghost" onClick={onClose}>Cancel</Button><Button variant="primary" icon={<Plus />} perm="finance.disbursement.record" disabled={!ok}
        onClick={() => { onDone({ disbursementId: 190, disbNo: 'DSB-DAR1-26-0190', consignmentId: Number(cons), billToPartyId: c?.billToPartyId ?? 2, payeeName: payee, chargeCode: code, description: CHARGE_NAMES[code].replace(' (paid on your behalf)', ''), currency: cur, amountPaid: m2(Number(amt)), paidAt: TODAY, payeeReceiptNo: rct, rebillMode: mode, handlingFee: m2(mode === 'AT_COST' ? 0 : Number(fee)), status: 'RECORDED', recordedBy: 'Neema Mushi' }); onClose(); setAmt(''); setRct(''); setFile(false); }}>Record disbursement</Button></>}>
      <div className="stack">
        <div className="form-grid">
          <Field label="Consignment" required hint={c ? `Billed to ${partyName(c.billToPartyId)}` : undefined}><Select value={cons} onChange={(e) => setCons(e.target.value)} options={consignments.map((x) => [String(x.consignmentId), x.refNo])} /></Field>
          <Field label="What was paid" required><Select value={code} onChange={(e) => { setCode(e.target.value); setPayee(e.target.value === 'DISB_DUTY' ? 'TRA customs (duty and taxes)' : e.target.value === 'DISB_LINE' ? partyName(consignment(Number(cons))?.shippingLinePartyId) : 'Port authority, Dar es Salaam port'); }} options={['DISB_PORT', 'DISB_LINE', 'DISB_DUTY'].map((x) => [x, CHARGE_NAMES[x].replace(' (paid on your behalf)', '')])} /></Field>
          <Field label="Paid to" required><Input value={payee} onChange={(e) => setPayee(e.target.value)} /></Field>
          <Field label="Currency"><Segmented value={cur} onChange={setCur} options={[{ id: 'USD', label: 'USD' }, { id: 'TZS', label: 'TZS' }]} /></Field>
          <Field label={`Amount paid (${cur})`} required><Input type="number" min={0} value={amt} onChange={(e) => setAmt(e.target.value)} /></Field>
          <Field label="Payee receipt no." required><Input value={rct} onChange={(e) => setRct(e.target.value.toUpperCase())} placeholder="PA-DSM-26-…" /></Field>
        </div>
        <Field label="Payee's receipt" required>
          <Button icon={file ? <CheckCircle2 /> : <Paperclip />} onClick={() => setFile(!file)}>{file ? 'receipt-scan.pdf attached' : 'Attach scanned receipt'}</Button>
        </Field>
        <Field label="Re-bill as">
          <Segmented value={mode} onChange={setMode} options={[{ id: 'AT_COST', label: 'At cost' }, { id: 'COST_PLUS_FEE', label: 'Cost plus handling fee' }]} />
        </Field>
        {mode === 'COST_PLUS_FEE' && <Field label={`Handling fee (${cur})`} hint="Separate line on the invoice, VAT 18%"><Input type="number" min={0} value={fee} onChange={(e) => setFee(e.target.value)} style={{ maxWidth: 160 }} /></Field>}
        <p className="xs muted">It goes on the customer's next invoice for this consignment. It can be billed only once.</p>
      </div>
    </Drawer>
  );
}
